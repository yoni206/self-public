fof(a1, axiom,
    ! [X0, X1, X2, X3, X4] :
        (X0 = op(op(X1,X2),op(X0,op(X1,X0))))
).

fof(conjecture0, conjecture,
    ! [X0, X1, X2, X3, X4] :
        (X0 = op(op(X1,X2),op(X3,op(X4,X0))))
).
