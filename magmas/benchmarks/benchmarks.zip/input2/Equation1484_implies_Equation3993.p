fof(a1, axiom,
    ! [X0, X1, X2, X3] :
        (X0 = op(op(X1,X0),op((X0 ◇ (X2 ◇ X0)) -- X3 1485 := X0 = (X1 ◇ X0),op(X0,op(X2,X1)))))
).

fof(conjecture0, conjecture,
    ! [X0, X1, X2, X3] :
        (op(X0,X1) = op(op(X2,op(X0,X1)),op(X1 -- X3 3994 := X0,op(X1 = (X2 ◇ (X0 ◇ X1)),X2))))
).
