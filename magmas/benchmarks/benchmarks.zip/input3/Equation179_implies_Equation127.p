fof(a1, axiom,
    ! [X0, X1] :
        (X0 = op(op(X1,X1),op(X1,X0)))
).

fof(conjecture0, conjecture,
    ! [X0, X1] :
        (X0 = op(X1,op(op(X1,X1),X0)))
).
