fof(a1, axiom,
    ! [X0, X1, X2, X3] :
        (X0 = op(op(X1,X0),op(op(X2,X2),X0)))
).

fof(conjecture0, conjecture,
    ! [X0, X1, X2, X3] :
        (X0 = op(op(op(X1,X1),X2),op(X3,X0)))
).
