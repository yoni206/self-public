fof(a1, axiom,
    ! [X0, X1, X2] :
        (X0 = op(op(op(X0,X1),X2),op(X1,X2)))
).

fof(conjecture0, conjecture,
    ! [X0, X1, X2] :
        (op(X0,X1) = op(X0,op(op(X1,X2),X2)))
).
