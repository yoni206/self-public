fof(a1, axiom,
    ! [X0, X1, X2, X3, X4] :
        (X0 = op(op(op(X0,X1),X0),op(X2,X2)))
).

fof(conjecture0, conjecture,
    ! [X0, X1, X2, X3, X4] :
        (X0 = op(op(op(X0,X1),op(X2,X3)),X4))
).
